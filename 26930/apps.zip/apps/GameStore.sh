#!/bin/bash

# 1. ค้นหาโฟลเดอร์ PortMaster
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

# 2. โหลดการตั้งค่า (ถ้ามี)
[ -f "$controlfolder/control.txt" ] && source "$controlfolder/control.txt"

# 3. เซ็ตพาทให้ Python รู้จัก Library ของ PortMaster
export LD_LIBRARY_PATH="$controlfolder/libs:$controlfolder/utils/lib:$LD_LIBRARY_PATH"
export PYTHONPATH="$controlfolder/exlibs:$controlfolder/pylibs:$controlfolder/libs:$PYTHONPATH"
export PYSDL2_DLL_PATH="$controlfolder/libs"

# 4. ชี้เป้าไปที่โฟลเดอร์สโตร์ของเรา
GAMEDIR="/opt/gamestore"
cd "$GAMEDIR"

sudo chmod 666 /dev/tty0
export TERM=linux
printf "\033c" > /dev/tty0

# 5. สั่งรันแอป (ย้าย Log ไปที่ /home/ark/ เพื่อกันปัญหาเขียนไฟล์ไม่ได้)
sudo ./gamestore > /home/ark/gamestore.log 2>&1

printf "\033c" > /dev/tty0