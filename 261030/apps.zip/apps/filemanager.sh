#!/bin/bash

# อ้างอิงโฟลเดอร์ใหม่ที่ย้ายไปไว้ใน /opt
APP_DIR="/opt/FindManager_Data"
cd "$APP_DIR"

export SDL_NOMOUSE=1

# คืนสิทธิ์ให้ตัวรัน (แก้ปัญหาเอาไฟล์ไปลงแล้วสิทธิ์ execute หาย)[cite: 15]
chmod +x FindManager

# ล้างหน้าจอ Console ดำๆ ก่อนเข้าแอป[cite: 15]
printf "\033c" > /dev/tty0

# รันโปรแกรมพร้อมเก็บ Log[cite: 15]
./FindManager > findmanager_log.txt 2>&1

# ล้างหน้าจออีกครั้งตอนกดออก เพื่อให้ตอนกลับเข้าเมนูหลัก (EmulationStation) ดูเนียนตา ไม่มี Text ขยะค้าง[cite: 15]
printf "\033c" > /dev/tty0