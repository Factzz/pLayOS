#!/bin/bash
# PortMaster launch script for YTC (Modified with Store Logic)

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

# 1. ค้นหาโฟลเดอร์ PortMaster (รองรับทั้ง SD1 และ SD2)
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
elif [ -d "/roms2/ports/PortMaster/" ]; then
  controlfolder="/roms2/ports/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

# 2. ชี้เป้าไปที่โฟลเดอร์ YTC ใน /opt
GAMEDIR="/opt/ytc"
cd "$GAMEDIR"

# 3. ย้าย Log ไปที่ /home/ark/ เพื่อหลีกเลี่ยงปัญหา Permission ใน /opt
> "/home/ark/ytc_log.txt" && exec > >(tee "/home/ark/ytc_log.txt") 2>&1

# 4. โหลด Library (สำคัญมาก: ห้ามใช้ sudo รันแอป ไม่งั้นค่าพวกนี้จะโดนระบบล้างทิ้ง)
export LD_LIBRARY_PATH="$GAMEDIR/libs.${DEVICE_ARCH}:$LD_LIBRARY_PATH"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
export YTC_MAXHEIGHT=480

# 5. เคลียร์หน้าจอดำและเปิดสิทธิ์ Terminal
sudo chmod 666 /dev/tty0
export TERM=linux
printf "\033c" > /dev/tty0

$GPTOKEYB "ytc.${DEVICE_ARCH}" &
pm_platform_helper "$GAMEDIR/ytc.${DEVICE_ARCH}"

# 6. รันแอปแบบปกติ (ใช้สิทธิ์จากการที่เรา chmod 777 โฟลเดอร์ไว้แล้ว)
./ytc.${DEVICE_ARCH}

pm_finish

# 7. เคลียร์หน้าจออีกรอบตอนกดออก
printf "\033c" > /dev/tty0