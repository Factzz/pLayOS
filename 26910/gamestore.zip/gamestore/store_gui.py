import sys
import os
import glob
import json
import urllib.request
import ssl
import zipfile
import gc
import threading
import shutil
from collections import deque

possible_pm_paths = [
    "/opt/system/Tools/PortMaster",
    "/opt/tools/PortMaster",
    "/roms/ports/PortMaster",
    "/roms2/ports/PortMaster",
    "../PortMaster"
]

pm_path = None
for path in possible_pm_paths:
    if os.path.exists(path):
        pm_path = path
        break

if pm_path:
    libs = os.path.join(pm_path, "libs")
    pylibs = os.path.join(pm_path, "pylibs")
    exlibs = os.path.join(pm_path, "exlibs")
    
    if os.path.exists(exlibs):
        sys.path.insert(0, exlibs)
    if os.path.exists(pylibs):
        sys.path.insert(0, pylibs)
        for zip_file in glob.glob(os.path.join(pylibs, "*.zip")):
            sys.path.insert(0, zip_file)
    if os.path.exists(libs):
        os.environ["PYSDL2_DLL_PATH"] = libs

try:
    import sdl2
    import sdl2.ext
    import sdl2.sdlttf as ttf
    from sdl2 import *
    try:
        import sdl2.sdlimage as sdlimage
        SDL_IMAGE_AVAILABLE = True
    except ImportError:
        SDL_IMAGE_AVAILABLE = False
        print("SDL2_image not available, using placeholder images")
except ImportError as e:
    print("SDL2 Error: " + str(e))
    sys.exit(1)

API_BASE = "http://r36swiki.com/getgames.php"
ROM_BASE_PATH = "/roms/"
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
ITEMS_PER_PAGE = 8  # แก้ให้พอดีกับ 4x2 Grid ของ UI ใหม่

ssl._create_default_https_context = ssl._create_unverified_context

CATEGORY_MAP = {
    "3do": "3do", "amigacd32": "amigacd32", "atari2600": "atari2600",
    "nes": "nes", "snes": "snes", "gba": "gba", "gb": "gb", "gbc": "gbc",
    "psx": "psx", "mame": "mame", "neogeo": "neogeo", "ports": "ports",
    "megadrive": "megadrive", "genesis": "megadrive", "n64": "n64",
    "nds": "nds", "psp": "psp", "dreamcast": "dreamcast", "saturn": "saturn",
    "pcengine": "pcengine", "mastersystem": "mastersystem", "gamegear": "gamegear"
}

CATEGORY_GROUPS = {
    "Nintendo": ["nes", "snes", "n64", "gb", "gbc", "gba", "nds"],
    "Sega": ["megadrive", "genesis", "mastersystem", "gamegear", "saturn", "dreamcast"],
    "Sony": ["psx", "psp"],
    "Arcade": ["mame", "neogeo"],
    "Diger": ["3do", "amigacd32", "atari2600", "pcengine", "ports"]
}

# ปรับสีธีมให้เป็น Apple Style Light Theme ที่สวยเนียนตา
CATEGORY_COLORS = {
    "nes": (200, 50, 50),
    "snes": (100, 50, 150),
    "n64": (50, 150, 50),
    "gb": (140, 160, 60),
    "gbc": (80, 180, 180),
    "gba": (100, 100, 200),
    "nds": (180, 180, 180),
    "megadrive": (30, 100, 200),
    "genesis": (30, 100, 200),
    "mastersystem": (200, 100, 100),
    "gamegear": (50, 50, 50),
    "saturn": (100, 100, 100),
    "dreamcast": (240, 130, 30),
    "psx": (100, 100, 100),
    "psp": (50, 50, 50),
    "mame": (220, 180, 50),
    "neogeo": (200, 50, 100),
    "3do": (50, 150, 100),
    "amigacd32": (200, 100, 50),
    "atari2600": (150, 100, 50),
    "pcengine": (255, 100, 100),
    "ports": (100, 200, 100),
    "ALL": (255, 200, 50)
}

CATEGORY_ICONS = {
    "nes": "[N]", "snes": "[S]", "n64": "[64]", "gb": "[GB]", "gbc": "[GC]", "gba": "[GA]",
    "nds": "[DS]", "megadrive": "[MD]", "genesis": "[MD]", "mastersystem": "[MS]",
    "gamegear": "[GG]", "saturn": "[ST]", "dreamcast": "[DC]", "psx": "[PS]",
    "psp": "[PP]", "mame": "[AR]", "neogeo": "[NG]", "3do": "[3D]", "amigacd32": "[AM]",
    "atari2600": "[AT]", "pcengine": "[PC]", "ports": "[PT]", "ALL": "[*]"
}

VIEW_CATEGORIES = 0
VIEW_GAMES = 1
VIEW_SEARCH = 2
VIEW_FAVORITES = 3
VIEW_GROUPS = 4
VIEW_GAME_DETAIL = 5
AXIS_THRESHOLD = 12000

class DownloadTask:
    def __init__(self, game, url, filepath, target_folder):
        self.game = game
        self.url = url
        self.filepath = filepath
        self.target_folder = target_folder
        self.progress = 0
        self.speed = 0
        self.downloaded = 0
        self.total_size = 0
        self.status = 'waiting'
        self.error_msg = ''
        self.cancelled = False

class Colors:
    # อัปเดตสีต่างๆ ให้สว่างสไตล์ iOS
    BG_TOP = (245, 245, 247)
    BG_BOTTOM = (245, 245, 247)
    HEADER_BG = (255, 255, 255, 240)
    HEADER_ACCENT = (230, 230, 235)
    HEADER_TEXT = (29, 29, 31)
    ITEM_BG = (255, 255, 255)
    ITEM_SELECTED_BG = (0, 122, 255)
    ITEM_SELECTED_GLOW = (0, 122, 255, 60)
    ITEM_TEXT = (29, 29, 31)
    ITEM_TEXT_SELECTED = (255, 255, 255)
    ITEM_SECONDARY = (134, 134, 139)
    FOOTER_BG = (255, 255, 255, 240)
    FOOTER_TEXT = (134, 134, 139)
    STATUS_OK = (52, 199, 89)
    STATUS_ERROR = (255, 59, 48)
    STATUS_LOADING = (0, 122, 255)
    ACCENT = (0, 122, 255)
    ACCENT_DARK = (0, 99, 204)
    PROGRESS_BG = (229, 229, 234)
    PROGRESS_FG = (0, 122, 255)
    TAB_ACTIVE = (99, 99, 102)
    TAB_INACTIVE = (209, 209, 214)
    SEARCH_BG = (229, 229, 234)
    SEARCH_CURSOR = (0, 122, 255)
    FAVORITE_STAR = (255, 149, 0)
    GROUP_HEADER = (29, 29, 31)
    BADGE_BG = (242, 242, 247)
    SCROLLBAR_BG = (229, 229, 234)
    SCROLLBAR_FG = (199, 199, 204)
    INFO_PANEL = (250, 250, 252)
    DIVIDER = (229, 229, 234)
    CYBER_CYAN = (0, 122, 255)
    CYBER_PINK = (255, 59, 48)
    CYBER_YELLOW = (0, 122, 255)
    CYBER_RED = (0, 122, 255)
    TEXT_DARK = (28, 28, 30)         
    TEXT_LIGHT = (255, 255, 255)     
    TEXT_MUTED = (142, 142, 147)

class GameStoreApp:
    def __init__(self):
        SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER)
        ttf.TTF_Init()
        
        self.window = SDL_CreateWindow(
            b"R36S Game Store",
            SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
            SCREEN_WIDTH, SCREEN_HEIGHT,
            SDL_WINDOW_SHOWN
        )
        self.renderer = SDL_CreateRenderer(self.window, -1, SDL_RENDERER_ACCELERATED)
        SDL_SetRenderDrawBlendMode(self.renderer, SDL_BLENDMODE_BLEND)
        
        self.joystick = None
        self.controller = None
        num_joy = SDL_NumJoysticks()
        print(f"Found {num_joy} joystick(s)")
        
        if num_joy > 0:
            if SDL_IsGameController(0):
                self.controller = SDL_GameControllerOpen(0)
                print("Opened as GameController")
            else:
                self.joystick = SDL_JoystickOpen(0)
                print("Opened as Joystick")
        
        font_path = None
        for fp in ["./font.ttf",
                   "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                   "/usr/share/fonts/TTF/DejaVuSans.ttf",
                   "/opt/system/Tools/PortMaster/themes/default.ttf"]:
            if os.path.exists(fp):
                font_path = fp
                break
        
        self.font = None
        self.font_large = None
        self.font_small = None
        if font_path:
            self.font = ttf.TTF_OpenFont(font_path.encode(), 16)
            self.font_large = ttf.TTF_OpenFont(font_path.encode(), 24)
            self.font_small = ttf.TTF_OpenFont(font_path.encode(), 13)
        
        if SDL_IMAGE_AVAILABLE:
            try:
                sdlimage.IMG_Init(sdlimage.IMG_INIT_JPG | sdlimage.IMG_INIT_PNG)
            except Exception as e:
                print(f"SDL_image init error: {e}")

        self.ui_assets = {}
        asset_map = {
            'bg': ['bg.png', 'bg_3.png', 'bg_2.png'],
            'card_normal': ['card_normal.png', 'card_normal_3.png', 'card_normal_2.png'],
            'card_focus': ['card_focus.png', 'card_focus_3.png', 'card_focus_2.png'],
            'gradient_overlay': ['gradient_overlay.png', 'gradient_overlay_4.png', 'gradient_overlay_3.png'],
            'tab_active': ['tab_active.png', 'tab_active_3.png', 'tab_active_2.png'],
            'tab_inactive': ['tab_inactive.png', 'tab_inactive_3.png', 'tab_inactive_2.png'],
            'badge': ['badge.png', 'badge_3.png', 'badge_2.png'],
            'logo': ['logo.png', 'logo_3.png', 'logo_2.png'],
            'con': ['con.png', 'con_2.png']
        }
        
        for key, filenames in asset_map.items():
            for name in filenames:
                path_root = f"./{name}"
                path_assets = f"./assets/{name}"
                target_path = path_root if os.path.exists(path_root) else (path_assets if os.path.exists(path_assets) else None)
                
                if target_path and SDL_IMAGE_AVAILABLE:
                    try:
                        surf = sdlimage.IMG_Load(target_path.encode())
                        if surf:
                            tex = SDL_CreateTextureFromSurface(self.renderer, surf)
                            self.ui_assets[key] = (tex, surf.contents.w, surf.contents.h)
                            SDL_FreeSurface(surf)
                            break
                    except Exception as e: pass

        self.text_cache = {}
        self.cache_limit = 100
        
        self.categories = []
        self.games = []
        self.view_mode = VIEW_CATEGORIES
        self.previous_view_mode = VIEW_CATEGORIES # ระบบจำหน้าเก่าเพื่อแก้บัคกดกลับ
        self.selected = 0
        self.scroll = 0
        self.current_cat = None
        self.page = 1
        self.total_pages = 1
        self.total_count = 0
        self.status = "Connecting..."
        self.status_type = "loading"
        self.running = True
        self.need_redraw = True
        self.frame_count = 0
        self.last_input_time = 0
        self.input_delay = 150
        
        # State สำหรับหน้ารายละเอียดเกม
        self.detail_game = None
        self.detail_action_idx = 0  # 0 = Download, 1 = Uninstall
        
        self.download_progress = 0
        self.is_downloading = False
        self.download_cancelled = False
        
        self.download_queue = deque()
        self.active_downloads = []
        self.completed_downloads = []
        self.max_concurrent_downloads = 2
        self.download_lock = threading.Lock()
        self.current_download_index = 0
        
        self.key_held = None
        self.key_hold_start = 0
        self.key_repeat_delay = 400
        self.key_repeat_interval = 80
        self.last_repeat_time = 0
        
        self.search_active = False
        self.search_query = ""
        self.search_results = []
        self.last_search_query = ""
        self.keyboard_layouts = {
            'letters': [
                list("QWERTYUIOP"),
                list("ASDFGHJKL"),
                list("ZXCVBNM"),
            ],
            'numbers': list("1234567890"),
            'symbols': list(".,?!'\"()-:;@")
        }
        self.keyboard_mode = 'letters'
        self.keyboard_row = 0
        self.keyboard_col = 0
        
        self.favorites = self.load_favorites()
        self.recent_games = self.load_recent()
        self.search_text = ""
        self.search_mode = False
        self.current_tab = 0
        self.tabs = ["Categories", "Favorites", "Recent"]
        self.animation_offset = 0
        self.target_scroll = 0
        self.show_info_panel = False
        self.grouped_categories = {}
        self.current_group = None
        
        self.image_cache = {}
        self.image_cache_limit = 20
        self.current_loading_image = None
        self.image_load_thread = None
        self.pending_image_data = None
        self.failed_images = set()
        self.image_cache_dir = os.path.join(os.path.dirname(__file__), ".image_cache")
        if not os.path.exists(self.image_cache_dir):
            try:
                os.makedirs(self.image_cache_dir)
            except:
                pass

    def create_text_texture(self, text, r, g, b, font=None):
        if not font:
            font = self.font
        if not font:
            return None, 0, 0
        
        color = SDL_Color(r, g, b, 255)
        surface = ttf.TTF_RenderUTF8_Blended(font, text.encode('utf-8'), color)
        if not surface:
            return None, 0, 0
        
        w = surface.contents.w
        h = surface.contents.h
        texture = SDL_CreateTextureFromSurface(self.renderer, surface)
        SDL_FreeSurface(surface)
        return texture, w, h

    def get_image_cache_path(self, url):
        import hashlib
        url_hash = hashlib.md5(url.encode()).hexdigest()
        ext = url.split('.')[-1].split('?')[0][:4]
        if ext not in ['jpg', 'jpeg', 'png', 'gif', 'bmp']:
            ext = 'jpg'
        return os.path.join(self.image_cache_dir, f"{url_hash}.{ext}")

    def download_image_async(self, url):
        def download_worker():
            try:
                cache_path = self.get_image_cache_path(url)
                
                if os.path.exists(cache_path):
                    self.pending_image_data = (url, cache_path)
                    self.need_redraw = True
                    return
                
                req = urllib.request.Request(url, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                
                with urllib.request.urlopen(req, timeout=15, context=ctx) as response:
                    image_data = response.read()
                    
                    try:
                        with open(cache_path, 'wb') as f:
                            f.write(image_data)
                        self.pending_image_data = (url, cache_path)
                        self.need_redraw = True
                    except Exception as e:
                        print(f"Image save error: {e}")
                        self.pending_image_data = None
            except Exception as e:
                print(f"Image download error for {url[:50]}...: {e}")
                self.failed_images.add(url)
                self.pending_image_data = None
            finally:
                self.current_loading_image = None
        
        self.current_loading_image = url
        self.pending_image_data = None
        self.image_load_thread = threading.Thread(target=download_worker, daemon=True)
        self.image_load_thread.start()

    def load_image_texture(self, url):
        if not url:
            return None
            
        if url in self.image_cache:
            return self.image_cache[url]
        
        if not hasattr(self, 'failed_images'):
            self.failed_images = set()
        if url in self.failed_images:
            return None
        
        if self.pending_image_data and self.pending_image_data[0] == url:
            cache_path = self.pending_image_data[1]
            self.pending_image_data = None
            
            if SDL_IMAGE_AVAILABLE and os.path.exists(cache_path):
                try:
                    sdlimage.IMG_Init(sdlimage.IMG_INIT_JPG | sdlimage.IMG_INIT_PNG)
                    
                    surface = sdlimage.IMG_Load(cache_path.encode())
                    if surface:
                        texture = SDL_CreateTextureFromSurface(self.renderer, surface)
                        w = surface.contents.w
                        h = surface.contents.h
                        SDL_FreeSurface(surface)
                        
                        if texture:
                            if len(self.image_cache) >= self.image_cache_limit:
                                oldest_key = next(iter(self.image_cache))
                                old_tex = self.image_cache[oldest_key][0]
                                if old_tex:
                                    SDL_DestroyTexture(old_tex)
                                del self.image_cache[oldest_key]
                            
                            self.image_cache[url] = (texture, w, h)
                            self.need_redraw = True
                            return (texture, w, h)
                    else:
                        print(f"SDL_image failed to load: {cache_path}")
                except Exception as e:
                    print(f"Image load error: {e}")
            elif not SDL_IMAGE_AVAILABLE:
                print("SDL2_image not available")
            
            return None
        
        cache_path = self.get_image_cache_path(url)
        if os.path.exists(cache_path):
            if SDL_IMAGE_AVAILABLE:
                try:
                    sdlimage.IMG_Init(sdlimage.IMG_INIT_JPG | sdlimage.IMG_INIT_PNG)
                    surface = sdlimage.IMG_Load(cache_path.encode())
                    if surface:
                        texture = SDL_CreateTextureFromSurface(self.renderer, surface)
                        w = surface.contents.w
                        h = surface.contents.h
                        SDL_FreeSurface(surface)
                        
                        if texture:
                            if len(self.image_cache) >= self.image_cache_limit:
                                oldest_key = next(iter(self.image_cache))
                                old_tex = self.image_cache[oldest_key][0]
                                if old_tex:
                                    SDL_DestroyTexture(old_tex)
                                del self.image_cache[oldest_key]
                            
                            self.image_cache[url] = (texture, w, h)
                            return (texture, w, h)
                except Exception as e:
                    print(f"Disk cache load error: {e}")
        
        if self.current_loading_image != url:
            self.download_image_async(url)
        
        return None

    def draw_game_image(self, x, y, width, height, image_url):
        if not image_url:
            return False
        
        result = self.load_image_texture(image_url)
        
        if result:
            texture, img_w, img_h = result
            if texture:
                dst = SDL_Rect(int(x), int(y), int(width), int(height))
                SDL_RenderCopy(self.renderer, texture, None, dst)
                return True
        
        return False

    def load_favorites(self):
        try:
            fav_path = os.path.join(os.path.dirname(__file__), "favorites.json")
            if os.path.exists(fav_path):
                with open(fav_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return []
    
    def save_favorites(self):
        try:
            fav_path = os.path.join(os.path.dirname(__file__), "favorites.json")
            with open(fav_path, 'w', encoding='utf-8') as f:
                json.dump(self.favorites, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Favorites save error: {e}")
    
    def load_recent(self):
        try:
            recent_path = os.path.join(os.path.dirname(__file__), "recent.json")
            if os.path.exists(recent_path):
                with open(recent_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return []
    
    def save_recent(self):
        try:
            recent_path = os.path.join(os.path.dirname(__file__), "recent.json")
            with open(recent_path, 'w', encoding='utf-8') as f:
                json.dump(self.recent_games[:20], f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Recent save error: {e}")
    
    def add_to_recent(self, game):
        self.recent_games = [g for g in self.recent_games if g.get('name') != game.get('name')]
        self.recent_games.insert(0, game)
        self.recent_games = self.recent_games[:20]
        self.save_recent()
    
    def toggle_favorite(self, game):
        game_name = game.get('name')
        existing = next((g for g in self.favorites if g.get('name') == game_name), None)
        if existing:
            self.favorites.remove(existing)
            self.status = f"'{game_name[:20]}' removed from favorites"
        else:
            self.favorites.append(game)
            self.status = f"'{game_name[:20]}' added to favorites"
        self.status_type = "ok"
        self.save_favorites()
        self.need_redraw = True
    
    def is_favorite(self, game):
        return any(g.get('name') == game.get('name') for g in self.favorites)
    
    def organize_categories_by_group(self):
        self.grouped_categories = {}
        for group_name, platforms in CATEGORY_GROUPS.items():
            self.grouped_categories[group_name] = []
            for cat in self.categories:
                cat_name = cat.get('category', '').lower()
                if cat_name in platforms:
                    self.grouped_categories[group_name].append(cat)
        
        grouped_cats = set()
        for platforms in CATEGORY_GROUPS.values():
            grouped_cats.update(platforms)
        
        for cat in self.categories:
            cat_name = cat.get('category', '').lower()
            if cat_name not in grouped_cats and cat_name != 'all':
                if "Diger" not in self.grouped_categories:
                    self.grouped_categories["Diger"] = []
                self.grouped_categories["Diger"].append(cat)

    def draw_text(self, text, x, y, color=(200, 200, 200), font=None, align="left"):
        text = str(text)[:70]
        key = (text, color, id(font))
        
        if key not in self.text_cache:
            if len(self.text_cache) > self.cache_limit:
                self.clear_cache()
            tex, w, h = self.create_text_texture(text, color[0], color[1], color[2], font)
            self.text_cache[key] = (tex, w, h)
        
        tex, w, h = self.text_cache[key]
        if tex:
            draw_x = int(x)
            if align == "center":
                draw_x = int(x - (w / 2))
            elif align == "right":
                draw_x = int(x - w)
                
            dst = SDL_Rect(draw_x, int(y), w, h)
            SDL_RenderCopy(self.renderer, tex, None, dst)
        return w if tex else 0

    def draw_rect(self, x, y, w, h, color, alpha=255):
        SDL_SetRenderDrawColor(self.renderer, color[0], color[1], color[2], alpha)
        rect = SDL_Rect(int(x), int(y), int(w), int(h))
        SDL_RenderFillRect(self.renderer, rect)

    def draw_gradient_rect(self, x, y, w, h, color_top, color_bottom, steps=10):
        step_h = h / steps
        for i in range(steps):
            t = i / steps
            r = int(color_top[0] + (color_bottom[0] - color_top[0]) * t)
            g = int(color_top[1] + (color_bottom[1] - color_top[1]) * t)
            b = int(color_top[2] + (color_bottom[2] - color_top[2]) * t)
            self.draw_rect(x, y + i * step_h, w, step_h + 1, (r, g, b))

    def draw_rounded_rect(self, x, y, w, h, color, alpha=255, radius=8):
        SDL_SetRenderDrawColor(self.renderer, color[0], color[1], color[2], alpha)
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x+radius), int(y), int(w-2*radius), int(h)))
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x), int(y+radius), int(w), int(h-2*radius)))
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x), int(y), int(radius), int(radius)))
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x+w-radius), int(y), int(radius), int(radius)))
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x), int(y+h-radius), int(radius), int(radius)))
        SDL_RenderFillRect(self.renderer, SDL_Rect(int(x+w-radius), int(y+h-radius), int(radius), int(radius)))

    def draw_progress_bar(self, x, y, w, h, percent):
        self.draw_rect(x, y, w, h, (20, 20, 25))
        self.draw_rect(x, y, w, 1, (40, 40, 45))
        self.draw_rect(x, y + h - 1, w, 1, (10, 10, 12))
        
        fill_w = int((w - 4) * percent / 100)
        if fill_w > 0:
            self.draw_rect(x + 2, y + 2, fill_w, h - 4, Colors.CYBER_YELLOW)
        
        percent_text = f"{int(percent)}%"
        text_x = x + w // 2 - 15
        if percent < 50:
            text_color = (255, 255, 255)
        else:
            text_color = (0, 0, 0)
        self.draw_text(percent_text, text_x, y + (h - 14) // 2, text_color, self.font_small)

    def draw_scrollbar(self, x, y, h, current, total, visible):
        if total <= visible:
            return
        
        self.draw_rounded_rect(x, y, 6, h, Colors.SCROLLBAR_BG, 150, 3)
        
        scroll_h = max(30, int(h * visible / total))
        scroll_y = y + int((h - scroll_h) * current / (total - visible)) if total > visible else y
        self.draw_rounded_rect(x, scroll_y, 6, scroll_h, Colors.SCROLLBAR_FG, 255, 3)

    def draw_category_badge(self, x, y, category):
        cat_lower = category.lower()
        color = CATEGORY_COLORS.get(cat_lower, (100, 100, 100))
        icon = CATEGORY_ICONS.get(cat_lower, "[?]")
        
        self.draw_rounded_rect(x, y, 28, 22, color, 200, 4)
        self.draw_text(icon, x + 8, y + 3, Colors.ITEM_TEXT_SELECTED, self.font_small)
    
    def draw_keyboard(self):
        keyboard_y = SCREEN_HEIGHT - 260
        key_w = 52
        key_h = 36
        key_gap = 4
        
        self.draw_rect(10, keyboard_y - 55, SCREEN_WIDTH - 20, 260, (10, 10, 15))
        self.draw_rect(10, keyboard_y - 55, SCREEN_WIDTH - 20, 2, Colors.CYBER_YELLOW)
        self.draw_rect(10, keyboard_y + 203, SCREEN_WIDTH - 20, 2, Colors.CYBER_YELLOW)
        
        search_box_x = 25
        search_box_y = keyboard_y - 45
        self.draw_rect(search_box_x, search_box_y, SCREEN_WIDTH - 50, 32, (15, 15, 20))
        self.draw_rect(search_box_x, search_box_y, SCREEN_WIDTH - 50, 1, Colors.CYBER_CYAN)
        
        display_text = self.search_query if self.search_query else "Search games..."
        text_color = Colors.CYBER_YELLOW if self.search_query else (60, 60, 65)
        text_width = self.draw_text(display_text, search_box_x + 12, search_box_y + 7, text_color, self.font)
        
        if self.search_query and (self.frame_count // 20) % 2 == 0:
            cursor_x = search_box_x + 12 + text_width + 2
            self.draw_rect(cursor_x, search_box_y + 6, 2, 20, Colors.CYBER_CYAN)
        
        char_count = f"{len(self.search_query)}/30"
        self.draw_text(char_count, SCREEN_WIDTH - 80, search_box_y + 8, (60, 60, 65), self.font_small)
        
        row_y = keyboard_y
        current_row = 0
        
        letters = self.keyboard_layouts['letters']
        row_offsets = [15, 35, 55]
        
        for row_idx, row_chars in enumerate(letters):
            row_len = len(row_chars)
            start_x = row_offsets[row_idx]
            
            for col_idx, char in enumerate(row_chars):
                x = start_x + col_idx * (key_w + key_gap)
                y = row_y + row_idx * (key_h + key_gap)
                
                is_selected = (self.keyboard_row == row_idx and self.keyboard_col == col_idx)
                
                if is_selected:
                    self.draw_rect(x, y, key_w, key_h, Colors.CYBER_YELLOW)
                    self.draw_text(char, x + key_w//2 - 5, y + 8, (0, 0, 0), self.font)
                else:
                    self.draw_rect(x, y, key_w, key_h, (20, 20, 25))
                    self.draw_rect(x, y + key_h - 1, key_w, 1, (30, 30, 35))
                    self.draw_text(char, x + key_w//2 - 5, y + 8, (120, 120, 120), self.font)
        
        current_row = 3
        
        num_row_y = row_y + 3 * (key_h + key_gap)
        if self.keyboard_mode == 'letters':
            row_chars = self.keyboard_layouts['numbers']
        else:
            row_chars = self.keyboard_layouts['symbols']
        
        num_key_w = 52
        num_start_x = 15
        
        for col_idx, char in enumerate(row_chars):
            x = num_start_x + col_idx * (num_key_w + key_gap)
            y = num_row_y
            
            is_selected = (self.keyboard_row == 3 and self.keyboard_col == col_idx)
            
            if is_selected:
                self.draw_rect(x, y, num_key_w, key_h, Colors.CYBER_YELLOW)
                self.draw_text(char, x + num_key_w//2 - 5, y + 8, (0, 0, 0), self.font)
            else:
                self.draw_rect(x, y, num_key_w, key_h, (20, 20, 25))
                self.draw_rect(x, y + key_h - 1, num_key_w, 1, (30, 30, 35))
                self.draw_text(char, x + num_key_w//2 - 5, y + 8, (100, 100, 100), self.font)
        
        ctrl_row_y = num_row_y + key_h + key_gap + 2
        
        special_keys = [
            ("?123" if self.keyboard_mode == 'letters' else "ABC", 60, 0),
            (",", 40, 1),
            ("_____", 200, 2),
            (".", 40, 3),
            ("<X", 55, 4),
            ("SRCH", 75, 5),
        ]
        
        key_x = 15
        for key_text, key_width, key_idx in special_keys:
            is_selected = (self.keyboard_row == 4 and self.keyboard_col == key_idx)
            
            if is_selected:
                bg_color = Colors.CYBER_YELLOW
                text_color = (0, 0, 0)
            elif key_idx == 5:
                bg_color = (0, 80, 65)
                text_color = Colors.CYBER_CYAN
            elif key_idx == 4:
                bg_color = (80, 20, 35)
                text_color = Colors.CYBER_PINK
            else:
                bg_color = (20, 20, 25)
                text_color = (100, 100, 100)
            
            self.draw_rect(key_x, ctrl_row_y, key_width, key_h, bg_color)
            if not is_selected:
                self.draw_rect(key_x, ctrl_row_y + key_h - 1, key_width, 1, (30, 30, 35))
            
            text_x = key_x + key_width//2 - len(key_text) * 4
            self.draw_text(key_text, text_x, ctrl_row_y + 8, text_color, self.font_small)
            
            key_x += key_width + key_gap
        
        help_y = ctrl_row_y + key_h + 8
        self.draw_text("DPAD: Select   A: Type   B: Close   START: Search", 100, help_y, (60, 60, 65), self.font_small)

    def api_call(self, params):
        try:
            encoded_params = []
            for k, v in params.items():
                encoded_value = urllib.request.quote(str(v), safe='')
                encoded_params.append(f"{k}={encoded_value}")
            url = API_BASE + "?" + "&".join(encoded_params)
            req = urllib.request.Request(url, headers={'User-Agent': 'R36S/1.0'})
            with urllib.request.urlopen(req, timeout=10) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            self.status = "Connection error"
            self.status_type = "error"
            print(f"API Error: {e}")
            return None
    
    def search_games(self, query, page=1):
        if not query or len(query) < 2:
            self.status = "Enter at least 2 characters"
            self.status_type = "error"
            return
        
        self.status = f"Searching '{query}'..."
        self.status_type = "loading"
        self.need_redraw = True
        self.render()
        
        self.last_search_query = query
        
        params = {"action": "search", "search": query, "page": page, "limit": ITEMS_PER_PAGE}
        data = self.api_call(params)
        
        if data and data.get('success'):
            self.search_results = data.get('games', [])
            if self.search_results:
                self.games = self.search_results
                self.view_mode = VIEW_GAMES
                self.current_cat = f"Search: {query}"
                self.page = data.get('page', 1)
                self.total_pages = data.get('total_pages', 1)
                self.total_count = data.get('total', len(self.search_results))
                self.selected = 0
                self.scroll = 0
                self.status = f"{self.total_count} results for '{query}'"
                self.status_type = "ok"
            else:
                self.status = f"No results for '{query}'"
                self.status_type = "error"
        else:
            error_msg = data.get('error', 'Unknown error') if data else "Connection error"
            self.status = f"Search error: {error_msg[:20]}"
            self.status_type = "error"
        
        self.search_active = False
        self.clear_cache()
        self.need_redraw = True

    def load_categories(self):
        self.status = "Loading categories..."
        self.status_type = "loading"
        self.need_redraw = True
        self.render()
        
        data = self.api_call({"action": "categories"})
        if data and data.get('success') and 'categories' in data:
            self.categories = data['categories']
            total = sum(c.get('count', 0) for c in self.categories)
            self.categories.insert(0, {'category': 'ALL', 'count': total})
            self.organize_categories_by_group()
            self.status = f"{len(self.categories)-1} platforms found"
            self.status_type = "ok"
        else:
            self.status = "Connection failed"
            self.status_type = "error"
        
        self.clear_cache()
        self.need_redraw = True

    def load_games(self):
        self.status = f"Loading page {self.page}..."
        self.status_type = "loading"
        self.need_redraw = True
        self.render()
        
        params = {"action": "games", "page": self.page, "limit": ITEMS_PER_PAGE}
        if self.current_cat and self.current_cat != 'ALL':
            params["category"] = self.current_cat
        
        data = self.api_call(params)
        if data and data.get('success'):
            self.games = data.get('games', [])
            self.page = data.get('page', 1)
            self.total_pages = data.get('total_pages', 1)
            self.total_count = data.get('total', 0)
            self.selected = 0
            self.scroll = 0
            self.status = f"{self.total_count} games available"
            self.status_type = "ok"
        else:
            self.games = []
            self.status = "Loading failed"
            self.status_type = "error"
        
        self.clear_cache()
        self.need_redraw = True

    def clear_cache(self):
        for tex, _, _ in self.text_cache.values():
            if tex:
                SDL_DestroyTexture(tex)
        self.text_cache.clear()
        gc.collect()

    def add_to_download_queue(self, game):
        url = game.get('game_path', '')
        if not url:
            self.status = "Download URL not found"
            self.status_type = "error"
            return False
        
        game_name = game.get('name', '')
        with self.download_lock:
            for task in list(self.download_queue) + self.active_downloads:
                if task.game.get('name') == game_name:
                    self.status = f"'{game_name[:20]}' already downloading"
                    self.status_type = "error"
                    return False
        
        if not url.startswith('http'):
            url = "http://r36swiki.com/" + url.lstrip('/')
        
        cat = game.get('category', 'ports').lower()
        folder = CATEGORY_MAP.get(cat, cat)
        target = os.path.join(ROM_BASE_PATH, folder)
        
        filename = urllib.request.unquote(url.split("/")[-1]) or "game.zip"
        filepath = os.path.join(target, filename)
        
        task = DownloadTask(game, url, filepath, target)
        
        with self.download_lock:
            self.download_queue.append(task)
        
        self.status = f"'{game_name[:20]}' added to queue"
        self.status_type = "ok"
        self.need_redraw = True
        
        self.process_download_queue()
        return True
    
    def process_download_queue(self):
        with self.download_lock:
            while len(self.active_downloads) < self.max_concurrent_downloads and self.download_queue:
                task = self.download_queue.popleft()
                self.active_downloads.append(task)
                thread = threading.Thread(target=self.download_task_thread, args=(task,), daemon=True)
                thread.start()
    
    def download_task_thread(self, task):
        task.status = 'downloading'
        self.need_redraw = True
        
        try:
            if not os.path.exists(task.target_folder):
                try:
                    os.makedirs(task.target_folder)
                except:
                    task.target_folder = ROM_BASE_PATH
            
            req = urllib.request.Request(task.url, headers={'User-Agent': 'R36S/1.0'})
            response = urllib.request.urlopen(req, timeout=60)
            
            total_size = response.headers.get('Content-Length')
            task.total_size = int(total_size) if total_size else 0
            
            downloaded = 0
            chunk_size = 8192
            last_time = SDL_GetTicks()
            last_downloaded = 0
            
            with open(task.filepath, 'wb') as f:
                while True:
                    if task.cancelled:
                        f.close()
                        try:
                            os.remove(task.filepath)
                        except:
                            pass
                        task.status = 'cancelled'
                        self.finish_download(task)
                        return
                    
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    task.downloaded = downloaded
                    
                    current_time = SDL_GetTicks()
                    time_diff = current_time - last_time
                    
                    if time_diff >= 500:
                        bytes_diff = downloaded - last_downloaded
                        task.speed = (bytes_diff / time_diff) * 1000
                        last_time = current_time
                        last_downloaded = downloaded
                    
                    if task.total_size > 0:
                        task.progress = (downloaded / task.total_size) * 100
                    else:
                        task.progress = min(99, downloaded / 10000)
                    
                    self.need_redraw = True
            
            if task.filepath.lower().endswith('.zip'):
                task.status = 'extracting'
                self.need_redraw = True
                with zipfile.ZipFile(task.filepath, 'r') as z:
                    z.extractall(task.target_folder)
                os.remove(task.filepath)
            
            task.progress = 100
            task.status = 'completed'
            self.add_to_recent(task.game)
            
        except Exception as e:
            task.status = 'error'
            task.error_msg = str(e)[:30]
            try:
                os.remove(task.filepath)
            except:
                pass
        
        self.finish_download(task)
    
    def finish_download(self, task):
        with self.download_lock:
            if task in self.active_downloads:
                self.active_downloads.remove(task)
            self.completed_downloads.append(task)
            if len(self.completed_downloads) > 10:
                self.completed_downloads.pop(0)
        
        self.process_download_queue()
        self.need_redraw = True
    
    def cancel_download(self, task):
        task.cancelled = True
        self.need_redraw = True
    
    def cancel_current_download(self):
        with self.download_lock:
            if self.active_downloads:
                idx = self.current_download_index % len(self.active_downloads)
                task = self.active_downloads[idx]
                task.cancelled = True
                self.status = f"Cancelling '{task.game.get('name', '')[:20]}'..."
                self.status_type = "loading"
                self.need_redraw = True
    
    def get_total_active_downloads(self):
        with self.download_lock:
            return len(self.active_downloads) + len(self.download_queue)
    
    def cycle_download_display(self):
        with self.download_lock:
            total = len(self.active_downloads)
            if total > 1:
                self.current_download_index = (self.current_download_index + 1) % total
                self.need_redraw = True
    
    def handle_select_button(self):
        with self.download_lock:
            active_count = len(self.active_downloads)
        
        if active_count > 1:
            self.cycle_download_display()
        elif active_count == 1:
            self.cancel_current_download()

    def check_is_installed(self, game):
        url = game.get('game_path', '')
        if not url:
            return False
        
        filename = urllib.request.unquote(url.split("/")[-1])
        base_name = filename.replace('.zip', '').replace('.7z', '')
        cat = game.get('category', 'ports').lower()
        folder = CATEGORY_MAP.get(cat, cat)
        target = os.path.join(ROM_BASE_PATH, folder)
        
        if os.path.exists(target):
            sh_file = os.path.join(target, base_name + '.sh')
            data_dir = os.path.join(target, base_name)
            zip_file = os.path.join(target, filename)
            gba_file = os.path.join(target, base_name + '.gba')
            nes_file = os.path.join(target, base_name + '.nes')
            
            if os.path.exists(sh_file) or os.path.exists(data_dir) or os.path.exists(zip_file) or os.path.exists(gba_file) or os.path.exists(nes_file):
                return True
                
            for f in os.listdir(target):
                if f.startswith(base_name):
                    return True
        return False

    def uninstall_game(self, game):
        url = game.get('game_path', '')
        if not url:
            self.status = "Cannot uninstall: missing path"
            self.status_type = "error"
            return
        
        filename = urllib.request.unquote(url.split("/")[-1])
        base_name = filename.replace('.zip', '').replace('.7z', '')
        cat = game.get('category', 'ports').lower()
        folder = CATEGORY_MAP.get(cat, cat)
        target = os.path.join(ROM_BASE_PATH, folder)
        
        deleted = False
        
        if os.path.exists(target):
            for f in os.listdir(target):
                if f.startswith(base_name):
                    full_path = os.path.join(target, f)
                    try:
                        if os.path.isdir(full_path):
                            shutil.rmtree(full_path)
                        else:
                            os.remove(full_path)
                        deleted = True
                    except Exception as e:
                        print(f"Delete error: {e}")
        
        game_name = game.get('name')
        
        original_recent_len = len(self.recent_games)
        self.recent_games = [g for g in self.recent_games if g.get('name') != game_name]
        if len(self.recent_games) < original_recent_len:
            self.save_recent()
            deleted = True
            
        original_fav_len = len(self.favorites)
        self.favorites = [g for g in self.favorites if g.get('name') != game_name]
        if len(self.favorites) < original_fav_len:
            self.save_favorites()
            
        if deleted:
            self.status = f"Uninstalled {game_name[:15]}"
            self.status_type = "ok"
            if self.current_tab == 2:
                self.need_redraw = True
        else:
            self.status = "Files not found or already removed"
            self.status_type = "error"

    def render_header(self):
        hx = 24
        hy = 18
        
        if self.view_mode == VIEW_GAME_DETAIL:
            self.draw_text("< GAME DETAILS", 20, 15, Colors.TEXT_DARK, self.font_large)
            return

        if 'logo' in self.ui_assets:
            tex, lw, lh = self.ui_assets['logo']
            target_h = 28
            target_w = int(lw * (target_h / lh))
            dst = SDL_Rect(hx, hy, target_w, target_h)
            SDL_RenderCopy(self.renderer, tex, None, dst)
            hx += target_w + 10
        else:
            self.draw_text("STORE", hx, hy, Colors.TEXT_DARK, self.font_large)
            
        tab_w = 90
        tab_h = 30
        tab_total_w = (len(self.tabs) * tab_w) + ((len(self.tabs) - 1) * 10)
        
        tx = (SCREEN_WIDTH // 2) - (tab_total_w // 2) 
        if tx < hx + 20: tx = hx + 20 
        
        for i, t in enumerate(self.tabs):
            is_sel = (i == self.current_tab)
            tc = Colors.TEXT_LIGHT if is_sel else Colors.TEXT_DARK
            
            asset_key = 'tab_active' if is_sel else 'tab_inactive'
            if asset_key in self.ui_assets:
                tex, _, _ = self.ui_assets[asset_key]
                dst = SDL_Rect(int(tx), int(hy), int(tab_w), int(tab_h))
                SDL_RenderCopy(self.renderer, tex, None, dst)
            else:
                bg = Colors.TAB_ACTIVE if is_sel else Colors.TAB_INACTIVE
                self.draw_rect(tx, hy, tab_w, tab_h, bg, 255)
            
            self.draw_text(t, tx + (tab_w // 2), hy + 7, tc, self.font_small, align="center")
            tx += tab_w + 10

    def render_categories(self):
        if self.current_tab == 0:
            self.render_category_list()
        elif self.current_tab == 1:
            self.render_game_list_items(self.favorites, show_category=True)
        elif self.current_tab == 2:
            self.render_game_list_items(self.recent_games, show_category=True)
    
    def render_category_list(self):
        items = self.categories
        if not items:
            self.draw_text("No categories found", 20, 150, Colors.ITEM_TEXT)
            return
            
        card_w = 240
        card_h = 160
        gap = 30
        center_x = SCREEN_WIDTH // 2 - card_w // 2
        center_y = (SCREEN_HEIGHT // 2) - (card_h // 2) + 15
        
        for i, item in enumerate(items):
            cat_name = item.get('category', '?')
            cat_lower = cat_name.lower()
            cat_color = CATEGORY_COLORS.get(cat_lower, (100, 120, 150))
            
            offset_x = (i - self.selected) * (card_w + gap)
            x = center_x + offset_x
            y = center_y
            
            if x + card_w < -50 or x > SCREEN_WIDTH + 50:
                continue
                
            is_selected = (i == self.selected)
            
            sys_img_path = f"assets/systems/{cat_lower}.png"
            sys_img_loaded = False
            
            if os.path.exists(sys_img_path):
                if sys_img_path not in self.ui_assets:
                    try:
                        surf = sdlimage.IMG_Load(sys_img_path.encode())
                        if surf:
                            tex = SDL_CreateTextureFromSurface(self.renderer, surf)
                            self.ui_assets[sys_img_path] = (tex, surf.contents.w, surf.contents.h)
                            SDL_FreeSurface(surf)
                    except: pass
                
                if sys_img_path in self.ui_assets:
                    tex, tw, th = self.ui_assets[sys_img_path]
                    
                    if is_selected:
                        # การ์ดตรงกลางที่ถูกเลือก: ขยายรูปให้ใหญ่และลอยเด่นขึ้น ไม่มีกล่องสีทับ
                        scale = 15
                        dst = SDL_Rect(int(x - scale), int(y - scale), int(card_w + scale*2), int(card_h + scale*2))
                    else:
                        # การ์ดด้านข้าง: ย่อรูปให้เล็กลง และดรอปสีลงนิดหน่อย ไม่มีกล่องสีทับ
                        dim_scale = 10
                        dst = SDL_Rect(int(x + dim_scale), int(y + dim_scale), int(card_w - dim_scale*2), int(card_h - dim_scale*2))
                        
                        SDL_SetTextureColorMod(tex, 150, 150, 150)
                        SDL_RenderCopy(self.renderer, tex, None, dst)
                        SDL_SetTextureColorMod(tex, 255, 255, 255)
                        sys_img_loaded = True
                        
                    if is_selected:
                        SDL_RenderCopy(self.renderer, tex, None, dst)
                        sys_img_loaded = True
            
            if not sys_img_loaded:
                # Fallback: ถ้าไม่มีรูป ก็วาดกล่องสีธรรมดา
                if is_selected:
                    self.draw_rounded_rect(x - 6, y - 6, card_w + 12, card_h + 12, Colors.CYBER_YELLOW, 255, 12)
                    self.draw_rounded_rect(x, y, card_w, card_h, cat_color, 255, 10)
                    font_to_use = self.font_large
                    y_offset = y + card_h//2 - 15
                else:
                    dim_color = (cat_color[0]//2, cat_color[1]//2, cat_color[2]//2)
                    self.draw_rounded_rect(x + 10, y + 10, card_w - 20, card_h - 20, dim_color, 255, 10)
                    font_to_use = self.font
                    y_offset = y + card_h//2 - 5
                
                self.draw_text(cat_name.upper(), x + card_w//2, y_offset, Colors.TEXT_LIGHT, font_to_use, align="center")
    
    def render_favorites_list(self):
        items = self.favorites
        if not items:
            self.draw_text("No favorite games yet", 150, 200, Colors.ITEM_TEXT)
            self.draw_text("Select a game and press Y to add favorite", 100, 230, Colors.ITEM_SECONDARY, self.font_small)
            return
        
        self.render_game_list_items(items, start_y=75, show_category=True, use_footer_limit=True)
    
    def render_recent_list(self):
        items = self.recent_games
        if not items:
            self.draw_text("No downloaded games yet", 180, 200, Colors.ITEM_TEXT)
            return
        
        self.render_game_list_items(items, start_y=75, show_category=True, use_footer_limit=True)
    
    def render_game_list_items(self, items, start_y=75, show_category=False, use_footer_limit=False):
        if self.selected >= len(items):
            self.selected = max(0, len(items) - 1)
        
        item_height = 80
        item_margin = 8
        footer_y = SCREEN_HEIGHT - 75
        
        if use_footer_limit:
            available_height = footer_y - start_y - 2
            visible_count = available_height // (item_height + item_margin)
        else:
            visible_count = 4 
            available_height = visible_count * (item_height + item_margin)
        
        if self.selected < self.scroll:
            self.scroll = self.selected
        elif self.selected >= self.scroll + visible_count:
            self.scroll = self.selected - visible_count + 1
        
        visible = items[self.scroll:self.scroll + visible_count]
        
        for i, item in enumerate(visible):
            idx = self.scroll + i
            y = start_y + i * (item_height + item_margin)
            is_selected = (idx == self.selected)
            
            name = item.get('name', 'Unknown')
            if len(name) > 35:
                name = name[:32] + "..."
            
            category = item.get('category', '')
            is_fav = self.is_favorite(item)
            is_installed = self.check_is_installed(item)
            
            if is_selected:
                self.draw_rect(15, y, SCREEN_WIDTH - 30, item_height, Colors.ITEM_SELECTED_BG, 255)
                text_color = Colors.TEXT_LIGHT
                status_ok_color = Colors.TEXT_LIGHT
                status_err_color = (200, 200, 200)
            else:
                self.draw_rect(15, y, SCREEN_WIDTH - 30, item_height, Colors.ITEM_BG, 255)
                self.draw_rect(20, y + item_height + 2, SCREEN_WIDTH - 40, 1, Colors.DIVIDER)
                text_color = Colors.TEXT_DARK
                status_ok_color = Colors.STATUS_OK
                status_err_color = Colors.TEXT_MUTED

            img_w = 60
            img_h = 70
            img_x = 25
            img_y = y + 5
            self.draw_rect(img_x, img_y, img_w, img_h, (40, 40, 45))
            image_url = item.get('image_url', '')
            if image_url:
                self.draw_game_image(img_x, img_y, img_w, img_h, image_url)
                
            text_x = img_x + img_w + 15
            
            self.draw_text(f"{idx + 1}.  {name}", text_x, y + 15, text_color, self.font)
            
            if is_installed:
                self.draw_text("Status: Installed", text_x, y + 45, status_ok_color, self.font_small)
            else:
                self.draw_text("Status: Not Installed", text_x, y + 45, status_err_color, self.font_small)
            
            if is_fav:
                self.draw_text("★", SCREEN_WIDTH - 40, y + 30, Colors.FAVORITE_STAR if not is_selected else Colors.TEXT_LIGHT, self.font)
            
            if show_category and category:
                badge_w = 60
                badge_x = SCREEN_WIDTH - 110
                if 'badge' in self.ui_assets:
                    tex, _, _ = self.ui_assets['badge']
                    dst = SDL_Rect(int(badge_x), int(y + 25), int(badge_w), 25)
                    SDL_RenderCopy(self.renderer, tex, None, dst)
                else:
                    self.draw_rect(badge_x, y + 25, badge_w, 25, Colors.CARD_BG, 255)
                self.draw_text(category[:6], badge_x + (badge_w // 2), y + 29, Colors.ITEM_SELECTED_BG, self.font_small, align="center")
        
        self.draw_scrollbar(SCREEN_WIDTH - 12, start_y, available_height,
                           self.scroll, len(items), visible_count)

    def render_games(self):
        page_text = f"Page {self.page}/{self.total_pages}"
        self.draw_text(page_text, SCREEN_WIDTH - 110, 60, Colors.TEXT_MUTED, self.font_small)

        items = self.games
        if not items:
            self.draw_text("No games found", 250, 200, Colors.TEXT_DARK)
            return
        
        cols = 4
        card_w = 130   
        card_h = 150   
        gap_x = 24 
        gap_y = 20 
        
        total_grid_w = (cols * card_w) + ((cols - 1) * gap_x)
        start_x = (SCREEN_WIDTH - total_grid_w) // 2 
        start_y = 90   

        if self.selected < self.scroll:
            self.scroll = self.selected
        elif self.selected >= self.scroll + ITEMS_PER_PAGE:
            self.scroll = self.selected - ITEMS_PER_PAGE + 1
        
        visible = items[self.scroll:self.scroll + ITEMS_PER_PAGE]

        def draw_game_card(i, item, is_selected):
            col = i % cols
            row = i // cols
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            
            game_name = item.get('name', 'Unknown')
            is_installed = self.check_is_installed(item)
            
            if is_selected:
                scale = 35  
                cur_w = card_w + (scale * 2)
                cur_h = card_h + (scale * 2)
                cur_x = x - scale
                cur_y = y - scale
                
                if 'card_focus' in self.ui_assets:
                    tex, _, _ = self.ui_assets['card_focus']
                    dst = SDL_Rect(int(cur_x), int(cur_y), int(cur_w), int(cur_h))
                    SDL_RenderCopy(self.renderer, tex, None, dst)
                else:
                    self.draw_rect(cur_x, cur_y, cur_w, cur_h, Colors.CARD_GLOW, 255)
                
                # ร่นเข้ามาเพื่อให้รูปไม่แทงขอบ (เพิ่มจาก 16 เป็น 24 ให้ลึกขึ้น)
                pad_x = 24 
                pad_y = 24 
                img_x = cur_x + pad_x
                img_y = cur_y + pad_y
                img_w = cur_w - (pad_x * 2)
                img_h = cur_h - (pad_y * 2)
                
                img = item.get('image_url', '')
                if img: self.draw_game_image(img_x, img_y, img_w, img_h, img)
                
                if is_installed:
                    self.draw_rounded_rect(img_x + 5, img_y + 5, 80, 20, Colors.STATUS_OK, 240, 4)
                    self.draw_text("INSTALLED", img_x + 45, img_y + 8, Colors.TEXT_DARK, self.font_small, align="center")
                
                if 'gradient_overlay' in self.ui_assets:
                    grad_h = int(img_h * 0.6)
                    tex, _, _ = self.ui_assets['gradient_overlay']
                    dst = SDL_Rect(int(img_x), int(img_y + img_h - grad_h), int(img_w), int(grad_h))
                    SDL_RenderCopy(self.renderer, tex, None, dst)
                else:
                    grad_h = int(img_h * 0.6)
                    self.draw_gradient_rect(img_x, img_y + img_h - grad_h, img_w, grad_h, (0,0,0), (0,0,0), 10)
                
                # ย่อฟอนต์เป็น self.font และจัดให้อยู่ตรงกลาง เพื่อไม่ให้ขอบล้น (ตัดบรรทัดเด็ดขาดที่ 14 ตัวอักษร)
                text_padding = 3
                text_x = img_x + (img_w // 2)
                
                words = game_name.split()
                lines = []
                cur_line = ""
                for w in words:
                    # จำกัดตัวอักษรต่อบรรทัดแบบเด็ดขาด (14 ตัวอักษร สำหรับ font ปกติ)
                    if len(cur_line) + len(w) + 1 <= 14: 
                        cur_line = (cur_line + " " + w).strip()
                    else:
                        if cur_line: lines.append(cur_line)
                        cur_line = w
                if cur_line: lines.append(cur_line)
                
                if len(lines) > 3:
                    lines = lines[:3]
                    lines[2] = lines[2][:11] + ".."
                elif len(lines) == 3 and len(lines[2]) > 14:
                    lines[2] = lines[2][:12] + ".."
                
                base_y = img_y + img_h - 40 - ((len(lines) - 1) * 18)
                for line_idx, line_text in enumerate(lines):
                    self.draw_text(line_text, text_x, base_y + (line_idx * 18), Colors.TEXT_LIGHT, self.font, align="center")
                
                self.draw_text("FREE", img_x + text_padding, img_y + img_h - 22, Colors.TEXT_LIGHT, self.font_small)
                if self.is_favorite(item):
                    self.draw_text("★", img_x + img_w - text_padding, img_y + img_h - 22, Colors.FAVORITE_STAR, self.font_small, align="right")
            else:
                display_name = game_name if len(game_name) <= 12 else game_name[:10] + ".."
                
                if 'card_normal' in self.ui_assets:
                    tex, _, _ = self.ui_assets['card_normal']
                    dst = SDL_Rect(int(x), int(y), 130, 150)
                    SDL_RenderCopy(self.renderer, tex, None, dst)
                else:
                    self.draw_rect(x, y, 130, 150, Colors.ITEM_BG, 255)
                
                pad_x = 10
                pad_y = 10
                img_x = x + pad_x
                img_y = y + pad_y
                img_w = 110
                img_h = 130
                
                img = item.get('image_url', '')
                if img: self.draw_game_image(img_x, img_y, img_w, img_h, img)
                
                if is_installed:
                    self.draw_rounded_rect(img_x + 3, img_y + 3, 65, 16, Colors.STATUS_OK, 240, 4)
                    self.draw_text("INSTALLED", img_x + 35, img_y + 5, Colors.TEXT_DARK, self.font_small, align="center")
                
                if 'gradient_overlay' in self.ui_assets:
                    grad_h = int(img_h * 0.6)
                    tex, _, _ = self.ui_assets['gradient_overlay']
                    dst = SDL_Rect(int(img_x), int(img_y + img_h - grad_h), int(img_w), int(grad_h))
                    SDL_RenderCopy(self.renderer, tex, None, dst)
                else:
                    grad_h = int(img_h * 0.6)
                    self.draw_gradient_rect(img_x, img_y + img_h - grad_h, img_w, grad_h, (0,0,0), (0,0,0), 10)
                
                text_x = img_x + (img_w // 2)
                self.draw_text(display_name, text_x, img_y + img_h - 35, Colors.TEXT_LIGHT, self.font, align="center")

        for i, item in enumerate(visible):
            is_selected = (self.scroll + i == self.selected)
            if not is_selected: 
                draw_game_card(i, item, False)
        
        for i, item in enumerate(visible):
            is_selected = (self.scroll + i == self.selected)
            if is_selected:
                draw_game_card(i, item, True)

    def render_game_detail(self):
        if not self.detail_game:
            return
            
        game = self.detail_game
        img_x = 40
        img_y = 100
        img_w = 200
        img_h = 240
        
        self.draw_rounded_rect(img_x - 2, img_y - 2, img_w + 4, img_h + 4, Colors.CYBER_YELLOW, 255, 8)
        self.draw_rect(img_x, img_y, img_w, img_h, Colors.ITEM_BG, 255)
        
        image_url = game.get('image_url', '')
        if image_url:
            self.draw_game_image(img_x, img_y, img_w, img_h, image_url)
            
        text_x = 270
        text_y = 110
        self.draw_text(game.get('name', 'Unknown')[:30], text_x, text_y, Colors.CYBER_YELLOW, self.font_large)
        text_y += 40
        self.draw_text(f"Platform: {game.get('category', 'Unknown').upper()}", text_x, text_y, Colors.TEXT_DARK, self.font)
        text_y += 30
        if self.is_favorite(game):
            self.draw_text("★ Favorited", text_x, text_y, Colors.FAVORITE_STAR, self.font)
            text_y += 30
            
        is_installed = self.check_is_installed(game)
        
        if is_installed:
            self.draw_text("Status: Installed", text_x, text_y, Colors.STATUS_OK, self.font)
        else:
            self.draw_text("Status: Not Installed", text_x, text_y, Colors.TEXT_MUTED, self.font)
            
        btn_y = 280
        btn_w = 140
        btn_h = 40
        
        b1_x = 270
        if self.detail_action_idx == 0:
            self.draw_rounded_rect(b1_x, btn_y, btn_w, btn_h, Colors.CYBER_YELLOW, 255, 8)
            self.draw_text("DOWNLOAD", b1_x + btn_w//2, btn_y + 12, Colors.TEXT_LIGHT, self.font, align="center")
        else:
            self.draw_rounded_rect(b1_x, btn_y, btn_w, btn_h, Colors.TAB_INACTIVE, 255, 8)
            self.draw_text("DOWNLOAD", b1_x + btn_w//2, btn_y + 12, Colors.TEXT_DARK, self.font, align="center")
            
        b2_x = 430
        if self.detail_action_idx == 1:
            self.draw_rounded_rect(b2_x, btn_y, btn_w, btn_h, Colors.CYBER_PINK, 255, 8)
            self.draw_text("UNINSTALL", b2_x + btn_w//2, btn_y + 12, Colors.TEXT_LIGHT, self.font, align="center")
        else:
            self.draw_rounded_rect(b2_x, btn_y, btn_w, btn_h, Colors.TAB_INACTIVE, 255, 8)
            self.draw_text("UNINSTALL", b2_x + btn_w//2, btn_y + 12, Colors.TEXT_DARK, self.font, align="center")

    def render_floating_controls(self):
        if 'con' in self.ui_assets:
            tex, cw, ch = self.ui_assets['con']
            target_h = 54
            target_w = int(cw * (target_h / ch))
            bar_x = SCREEN_WIDTH - target_w - 20
            bar_y = SCREEN_HEIGHT - target_h - 15
            dst = SDL_Rect(int(bar_x), int(bar_y), int(target_w), int(target_h))
            SDL_RenderCopy(self.renderer, tex, None, dst)
        else:
            bar_w = 400 
            bar_h = 54
            bar_x = SCREEN_WIDTH - bar_w - 20
            bar_y = SCREEN_HEIGHT - bar_h - 15
            self.draw_rounded_rect(bar_x, bar_y, bar_w, bar_h, Colors.TAB_INACTIVE, 230, 18)
            cx = bar_x + (bar_w // 2)
            cy = bar_y + 18
            self.draw_text("[B] Back     [L/R] Tabs     [A] Ok", cx, cy, Colors.TEXT_DARK, self.font, align="center")

    def render_footer(self):
        with self.download_lock:
            active_count = len(self.active_downloads)
            queue_count = len(self.download_queue)
            has_downloads = active_count > 0 or queue_count > 0
        
        if has_downloads:
            footer_y = SCREEN_HEIGHT - 65
            self.draw_rect(0, footer_y, SCREEN_WIDTH, 65, Colors.ITEM_BG, 255)
            self.draw_rect(0, footer_y, SCREEN_WIDTH, 1, Colors.TAB_INACTIVE, 255)
            
            with self.download_lock:
                if self.active_downloads:
                    idx = self.current_download_index % len(self.active_downloads)
                    task = self.active_downloads[idx]
                    game_name = task.game.get('name', 'Unknown')[:25]
                    
                    self.draw_rect(20, footer_y + 10, SCREEN_WIDTH - 40, 12, Colors.TAB_INACTIVE, 255)
                    fill_w = int((SCREEN_WIDTH - 40) * task.progress / 100)
                    if fill_w > 0:
                        self.draw_rect(20, footer_y + 10, fill_w, 12, Colors.STATUS_LOADING, 255)
                    
                    if task.status == 'downloading':
                        dm = task.downloaded / (1024 * 1024)
                        tm = task.total_size / (1024 * 1024) if task.total_size > 0 else 0
                        sm = task.speed / (1024 * 1024)
                        size_text = f"{dm:.1f}/{tm:.1f}MB" if tm > 0 else f"{dm:.1f}MB"
                        speed_text = f"{sm:.1f}MB/s" if sm >= 1 else f"{task.speed/1024:.0f}KB/s"
                        status_text = f"Downloading: {game_name} | {size_text} | {speed_text}"
                    elif task.status == 'extracting':
                        status_text = f"Extracting: {game_name}"
                    else:
                        status_text = f"Waiting: {game_name}"
                    
                    self.draw_text(status_text, 20, footer_y + 35, Colors.STATUS_LOADING, self.font_small)
                    self.draw_text("[START] Cancel", SCREEN_WIDTH - 20, footer_y + 35, Colors.STATUS_ERROR, self.font_small, align="right")
                else:
                    self.draw_text(f"Queued: {queue_count} games", 20, footer_y + 25, Colors.STATUS_LOADING, self.font)
        else:
            self.render_floating_controls()

    def render(self):
        if 'bg' in self.ui_assets:
            tex, _, _ = self.ui_assets['bg']
            SDL_RenderCopy(self.renderer, tex, None, SDL_Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
        else:
            self.draw_rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Colors.BG_TOP, 255)
            
        self.render_header()
        
        if self.view_mode == VIEW_CATEGORIES:
            self.render_categories()
        elif self.view_mode == VIEW_GAMES:
            self.render_games()
        elif self.view_mode == VIEW_GAME_DETAIL:
            self.render_game_detail()
            
        self.render_footer()
        
        if self.search_active:
            self.draw_rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, (0, 0, 0), 150)
            self.draw_keyboard()
            
        SDL_RenderPresent(self.renderer)
        self.need_redraw = False
        self.frame_count += 1

    def action_up(self):
        if self.view_mode == VIEW_GAMES:
            cols = 4
            if self.selected >= cols:
                self.selected -= cols
                self.need_redraw = True
        elif self.view_mode == VIEW_CATEGORIES:
            if self.current_tab in (1, 2):
                if self.selected > 0:
                    self.selected -= 1
                    self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            pass 

    def action_down(self):
        if self.view_mode == VIEW_GAMES:
            cols = 4
            if self.selected + cols < len(self.games):
                self.selected += cols
                self.need_redraw = True
        elif self.view_mode == VIEW_CATEGORIES:
            if self.current_tab == 1:
                if self.selected < len(self.favorites) - 1:
                    self.selected += 1
                    self.need_redraw = True
            elif self.current_tab == 2:
                if self.selected < len(self.recent_games) - 1:
                    self.selected += 1
                    self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            pass 

    def action_left(self):
        if self.view_mode == VIEW_GAMES:
            cols = 4
            if self.selected % cols > 0:
                self.selected -= 1
                self.need_redraw = True
            elif self.page > 1:
                self.page -= 1
                if self.last_search_query and self.current_cat and self.current_cat.startswith("Search:"):
                    self.search_games(self.last_search_query, self.page)
                else:
                    self.load_games()
                self.selected = min(self.selected + (cols - 1), len(self.games) - 1) if self.games else 0
        elif self.view_mode == VIEW_CATEGORIES:
            if self.current_tab == 0:
                if self.selected > 0:
                    self.selected -= 1
                    self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            self.detail_action_idx = max(0, self.detail_action_idx - 1)
            self.need_redraw = True

    def action_right(self):
        if self.view_mode == VIEW_GAMES:
            cols = 4
            if self.selected % cols < cols - 1 and self.selected < len(self.games) - 1:
                self.selected += 1
                self.need_redraw = True
            elif self.page < self.total_pages:
                self.page += 1
                if self.last_search_query and self.current_cat and self.current_cat.startswith("Search:"):
                    self.search_games(self.last_search_query, self.page)
                else:
                    self.load_games()
                self.selected = self.selected - (cols - 1) if self.selected >= (cols - 1) else 0
        elif self.view_mode == VIEW_CATEGORIES:
            if self.current_tab == 0:
                if self.selected < len(self.categories) - 1:
                    self.selected += 1
                    self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            self.detail_action_idx = min(1, self.detail_action_idx + 1)
            self.need_redraw = True
    
    def action_favorite(self):
        if self.view_mode == VIEW_GAMES and self.games:
            game = self.games[self.selected]
            self.toggle_favorite(game)
        elif self.view_mode == VIEW_CATEGORIES:
            if self.current_tab == 1 and self.favorites:
                game = self.favorites[self.selected]
                self.toggle_favorite(game)
            elif self.current_tab == 2 and self.recent_games:
                game = self.recent_games[self.selected]
                self.toggle_favorite(game)
    
    def action_search(self):
        self.search_active = True
        self.search_query = ""
        self.keyboard_row = 0
        self.keyboard_col = 0
        self.need_redraw = True
    
    def handle_keyboard_input(self, direction):
        letters = self.keyboard_layouts['letters']
        
        row_lengths = [
            len(letters[0]),
            len(letters[1]),
            len(letters[2]),
            10,
            6
        ]
        
        if direction == "up":
            if self.keyboard_row > 0:
                self.keyboard_row -= 1
                max_col = row_lengths[self.keyboard_row] - 1
                if row_lengths[self.keyboard_row + 1] > 0:
                    ratio = self.keyboard_col / row_lengths[self.keyboard_row + 1]
                    self.keyboard_col = min(int(ratio * row_lengths[self.keyboard_row]), max_col)
                else:
                    self.keyboard_col = min(self.keyboard_col, max_col)
        
        elif direction == "down":
            if self.keyboard_row < 4:
                self.keyboard_row += 1
                max_col = row_lengths[self.keyboard_row] - 1
                if row_lengths[self.keyboard_row - 1] > 0:
                    ratio = self.keyboard_col / row_lengths[self.keyboard_row - 1]
                    self.keyboard_col = min(int(ratio * row_lengths[self.keyboard_row]), max_col)
                else:
                    self.keyboard_col = min(self.keyboard_col, max_col)
        
        elif direction == "left":
            if self.keyboard_col > 0:
                self.keyboard_col -= 1
        
        elif direction == "right":
            max_col = row_lengths[self.keyboard_row] - 1
            if self.keyboard_col < max_col:
                self.keyboard_col += 1
        
        self.need_redraw = True
    
    def handle_keyboard_select(self):
        letters = self.keyboard_layouts['letters']
        
        if self.keyboard_row < 3:
            row_chars = letters[self.keyboard_row]
            if self.keyboard_col < len(row_chars):
                char = row_chars[self.keyboard_col]
                if len(self.search_query) < 30:
                    self.search_query += char
        
        elif self.keyboard_row == 3:
            if self.keyboard_mode == 'letters':
                chars = self.keyboard_layouts['numbers']
            else:
                chars = self.keyboard_layouts['symbols']
            
            if self.keyboard_col < len(chars):
                char = chars[self.keyboard_col]
                if len(self.search_query) < 30:
                    self.search_query += char
        
        elif self.keyboard_row == 4:
            if self.keyboard_col == 0:
                self.keyboard_mode = 'symbols' if self.keyboard_mode == 'letters' else 'letters'
            elif self.keyboard_col == 1:
                if len(self.search_query) < 30:
                    self.search_query += ","
            elif self.keyboard_col == 2:
                if len(self.search_query) < 30:
                    self.search_query += " "
            elif self.keyboard_col == 3:
                if len(self.search_query) < 30:
                    self.search_query += "."
            elif self.keyboard_col == 4:
                if self.search_query:
                    self.search_query = self.search_query[:-1]
            elif self.keyboard_col == 5:
                if self.search_query.strip():
                    self.search_games(self.search_query.strip())
        
        self.need_redraw = True
    
    def handle_keyboard_search(self):
        if self.search_query.strip():
            self.search_games(self.search_query.strip())
    
    def handle_keyboard_back(self):
        self.search_active = False
        self.search_query = ""
        self.need_redraw = True

    def action_select(self):
        if self.view_mode == VIEW_CATEGORIES:
            if self.current_tab == 0 and self.categories:
                cat = self.categories[self.selected].get('category')
                self.current_cat = None if cat == 'ALL' else cat
                self.view_mode = VIEW_GAMES
                self.selected = 0
                self.scroll = 0
                self.page = 1
                self.load_games()
            elif self.current_tab == 1 and self.favorites:
                self.install_game_from_list(self.favorites)
            elif self.current_tab == 2 and self.recent_games:
                self.install_game_from_list(self.recent_games)
        elif self.view_mode == VIEW_GAMES:
            if self.games:
                self.detail_game = self.games[self.selected]
                self.detail_action_idx = 0
                self.previous_view_mode = self.view_mode
                self.view_mode = VIEW_GAME_DETAIL
                self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            if self.detail_action_idx == 0:
                self.add_to_download_queue(self.detail_game)
                self.view_mode = getattr(self, 'previous_view_mode', VIEW_GAMES)
            else:
                self.uninstall_game(self.detail_game)
                self.view_mode = getattr(self, 'previous_view_mode', VIEW_GAMES)
            self.need_redraw = True
    
    def install_game_from_list(self, game_list):
        if not game_list or self.selected >= len(game_list):
            return
        
        self.detail_game = game_list[self.selected]
        self.detail_action_idx = 0
        self.previous_view_mode = self.view_mode
        self.view_mode = VIEW_GAME_DETAIL
        self.need_redraw = True

    def action_back(self):
        if self.view_mode == VIEW_GAMES:
            self.view_mode = VIEW_CATEGORIES
            self.selected = 0
            self.scroll = 0
            self.games = []
            self.last_search_query = ""
            self.clear_cache()
            self.status = f"{len(self.categories)-1} platforms found"
            self.status_type = "ok"
            self.need_redraw = True
        elif self.view_mode == VIEW_GAME_DETAIL:
            self.view_mode = getattr(self, 'previous_view_mode', VIEW_GAMES)
            self.need_redraw = True
        else:
            self.running = False

    def process_key_repeat(self):
        if not self.key_held or self.search_active:
            return
        
        now = SDL_GetTicks()
        hold_duration = now - self.key_hold_start
        
        if hold_duration < self.key_repeat_delay:
            return
        
        if now - self.last_repeat_time >= self.key_repeat_interval:
            self.last_repeat_time = now
            
            if self.key_held == 'up':
                self.action_up()
            elif self.key_held == 'down':
                self.action_down()
            elif self.key_held == 'left':
                self.action_left()
            elif self.key_held == 'right':
                self.action_right()
    
    def handle_event(self, event):
        now = SDL_GetTicks()
        
        if self.search_active:
            if event.type == SDL_KEYDOWN:
                key = event.key.keysym.sym
                if key in (SDLK_UP, SDLK_w):
                    self.handle_keyboard_input("up")
                elif key in (SDLK_DOWN, SDLK_s):
                    self.handle_keyboard_input("down")
                elif key in (SDLK_LEFT, SDLK_a):
                    self.handle_keyboard_input("left")
                elif key in (SDLK_RIGHT, SDLK_d):
                    self.handle_keyboard_input("right")
                elif key in (SDLK_SPACE, SDLK_z):
                    self.handle_keyboard_select()
                elif key == SDLK_RETURN:
                    self.handle_keyboard_search()
                elif key == SDLK_BACKSPACE:
                    if self.search_query:
                        self.search_query = self.search_query[:-1]
                        self.need_redraw = True
                elif key in (SDLK_ESCAPE, SDLK_x):
                    self.handle_keyboard_back()
            elif event.type == SDL_CONTROLLERBUTTONDOWN:
                btn = event.cbutton.button
                if btn == SDL_CONTROLLER_BUTTON_DPAD_UP:
                    self.handle_keyboard_input("up")
                elif btn == SDL_CONTROLLER_BUTTON_DPAD_DOWN:
                    self.handle_keyboard_input("down")
                elif btn == SDL_CONTROLLER_BUTTON_DPAD_LEFT:
                    self.handle_keyboard_input("left")
                elif btn == SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
                    self.handle_keyboard_input("right")
                elif btn == SDL_CONTROLLER_BUTTON_A:
                    self.handle_keyboard_select()
                elif btn == SDL_CONTROLLER_BUTTON_B:
                    self.handle_keyboard_back()
                elif btn == SDL_CONTROLLER_BUTTON_START:
                    self.handle_keyboard_search()
                elif btn == SDL_CONTROLLER_BUTTON_Y:
                    if self.search_query:
                        self.search_query = self.search_query[:-1]
                        self.need_redraw = True
            return
        
        if event.type == SDL_KEYDOWN:
            key = event.key.keysym.sym
            if key in (SDLK_UP, SDLK_w):
                self.action_up()
            elif key in (SDLK_DOWN, SDLK_s):
                self.action_down()
            elif key in (SDLK_LEFT, SDLK_a, SDLK_PAGEUP):
                self.action_left()
            elif key in (SDLK_RIGHT, SDLK_d, SDLK_PAGEDOWN):
                self.action_right()
            elif key in (SDLK_RETURN, SDLK_SPACE, SDLK_z):
                self.action_select()
            elif key in (SDLK_ESCAPE, SDLK_BACKSPACE):
                self.action_back()
            elif key == SDLK_y or key == SDLK_f:
                self.action_favorite()
            elif key == SDLK_x:
                self.action_search()
            elif key == SDLK_TAB:
                self.cycle_download_display()
        
        elif event.type == SDL_CONTROLLERBUTTONDOWN:
            btn = event.cbutton.button
            print(f"Controller button: {btn}")
            if btn == SDL_CONTROLLER_BUTTON_A:
                self.action_select()
            elif btn == SDL_CONTROLLER_BUTTON_B:
                self.action_back()
            elif btn == SDL_CONTROLLER_BUTTON_Y:
                self.action_favorite()
            elif btn == SDL_CONTROLLER_BUTTON_X:
                self.action_search()
            elif btn == SDL_CONTROLLER_BUTTON_BACK:
                self.handle_select_button()
            elif btn == SDL_CONTROLLER_BUTTON_START:
                self.cancel_current_download()
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_UP:
                self.action_up()
                self.key_held = 'up'
                self.key_hold_start = now
                self.last_repeat_time = now
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_DOWN:
                self.action_down()
                self.key_held = 'down'
                self.key_hold_start = now
                self.last_repeat_time = now
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_LEFT:
                self.action_left()
                self.key_held = 'left'
                self.key_hold_start = now
                self.last_repeat_time = now
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
                self.action_right()
                self.key_held = 'right'
                self.key_hold_start = now
                self.last_repeat_time = now
            elif btn == SDL_CONTROLLER_BUTTON_LEFTSHOULDER:
                if self.view_mode == VIEW_CATEGORIES:
                    self.current_tab = (self.current_tab - 1) % len(self.tabs)
                    self.selected = 0
                    self.scroll = 0
                    self.need_redraw = True
                else:
                    self.action_left()
            elif btn == SDL_CONTROLLER_BUTTON_RIGHTSHOULDER:
                if self.view_mode == VIEW_CATEGORIES:
                    self.current_tab = (self.current_tab + 1) % len(self.tabs)
                    self.selected = 0
                    self.scroll = 0
                    self.need_redraw = True
                else:
                    self.action_right()
        
        elif event.type == SDL_CONTROLLERBUTTONUP:
            btn = event.cbutton.button
            if btn == SDL_CONTROLLER_BUTTON_DPAD_UP and self.key_held == 'up':
                self.key_held = None
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_DOWN and self.key_held == 'down':
                self.key_held = None
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_LEFT and self.key_held == 'left':
                self.key_held = None
            elif btn == SDL_CONTROLLER_BUTTON_DPAD_RIGHT and self.key_held == 'right':
                self.key_held = None
        
        elif event.type == SDL_JOYBUTTONDOWN:
            if now - self.last_input_time > self.input_delay:
                self.last_input_time = now
                self.need_redraw = True
        
        elif event.type == SDL_JOYHATMOTION:
            hat = event.jhat.value
            if hat & SDL_HAT_UP:
                if self.key_held != 'up':
                    self.action_up()
                    self.key_held = 'up'
                    self.key_hold_start = now
                    self.last_repeat_time = now
            elif hat & SDL_HAT_DOWN:
                if self.key_held != 'down':
                    self.action_down()
                    self.key_held = 'down'
                    self.key_hold_start = now
                    self.last_repeat_time = now
            elif hat & SDL_HAT_LEFT:
                if self.key_held != 'left':
                    self.action_left()
                    self.key_held = 'left'
                    self.key_hold_start = now
                    self.last_repeat_time = now
            elif hat & SDL_HAT_RIGHT:
                if self.key_held != 'right':
                    self.action_right()
                    self.key_held = 'right'
                    self.key_hold_start = now
                    self.last_repeat_time = now
            else:
                self.key_held = None
        
        elif event.type == SDL_JOYAXISMOTION:
            axis = event.jaxis.axis
            value = event.jaxis.value
            
            if now - self.last_input_time > self.input_delay:
                if abs(value) > AXIS_THRESHOLD:
                    if axis == 1:
                        if value < -AXIS_THRESHOLD:
                            self.action_up()
                            self.last_input_time = now
                        elif value > AXIS_THRESHOLD:
                            self.action_down()
                            self.last_input_time = now
                    elif axis == 0:
                        if value < -AXIS_THRESHOLD:
                            self.action_left()
                            self.last_input_time = now
                        elif value > AXIS_THRESHOLD:
                            self.action_right()
                            self.last_input_time = now

    def run(self):
        self.load_categories()
        
        event = SDL_Event()
        
        while self.running:
            while SDL_PollEvent(event):
                if event.type == SDL_QUIT:
                    self.running = False
                else:
                    self.handle_event(event)
            
            self.process_key_repeat()
            
            if self.pending_image_data:
                self.need_redraw = True
            
            if self.need_redraw:
                self.render()
            SDL_Delay(16)
        
        self.clear_cache()
        if self.font:
            ttf.TTF_CloseFont(self.font)
        if self.font_large:
            ttf.TTF_CloseFont(self.font_large)
        if self.font_small:
            ttf.TTF_CloseFont(self.font_small)
        
        for key in list(self.ui_assets.keys()):
            tex, _, _ = self.ui_assets[key]
            if tex:
                SDL_DestroyTexture(tex)
            del self.ui_assets[key]
            
        if self.controller:
            SDL_GameControllerClose(self.controller)
        if self.joystick:
            SDL_JoystickClose(self.joystick)
        ttf.TTF_Quit()
        SDL_DestroyRenderer(self.renderer)
        SDL_DestroyWindow(self.window)
        SDL_Quit()
        return 0

if __name__ == "__main__":
    try:
        app = GameStoreApp()
        sys.exit(app.run())
    except Exception as e:
        print(f"FATAL: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)