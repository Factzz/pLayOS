#!/bin/bash
sudo max_toggle.sh
export KODI_HOME=/opt/kodi/share/kodi

if [ -e "/home/ark/.config/.IMAGEDELAYTIME" ]; then
  delay="$(cat /home/ark/.config/.IMAGEDELAYTIME)"
else
  delay="1.5"
fi
if [ -f "/roms/launchimages/loading.jpg" ]; then
  image-viewer /roms/launchimages/loading.jpg &
  PROC=$!
  (sleep ${delay}s; kill -9 $PROC)
fi

export MALLOC_MMAP_THRESHOLD_=131072
cd /opt/kodi
/opt/kodi/lib/kodi/kodi-gbm

if [ -e "/home/ark/.config/.IMAGEDELAYTIME" ]; then
  delay="$(cat /home/ark/.config/.IMAGEDELAYTIME)"
else
  delay="1.5"
fi
if [ -f "/roms/launchimages/loading.jpg" ]; then
  image-viewer /roms/launchimages/loading.jpg &
  PROC=$!
  (sleep ${delay}s; kill -9 $PROC)
fi

sudo systemctl restart ogage &
sudo max_toggle.sh
printf "\033c" >> /dev/tty1