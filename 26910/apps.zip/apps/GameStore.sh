#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

export LD_LIBRARY_PATH="$controlfolder/libs:$controlfolder/utils/lib:$LD_LIBRARY_PATH"
export PYTHONPATH="$controlfolder/exlibs:$controlfolder/pylibs:$controlfolder/libs:$PYTHONPATH"
export PYSDL2_DLL_PATH="$controlfolder/libs"

# รันแอปจากระบบหลักโดยตรง
GAMEDIR="/opt/gamestore"
cd $GAMEDIR

$ESUDO chmod 666 /dev/tty0
export TERM=linux
printf "\033c" > /dev/tty0

$ESUDO python3 store_gui.py > "$GAMEDIR/log.txt" 2>&1

printf "\033c" > /dev/tty0