#!/bin/bash
# PortMaster launch script for YTC.
# Uses the CFW's SDL2 + GLES2/EGL (device GPU driver) and libass/ALSA. libmpv +
# ffmpeg 6.1 are BUNDLED in libs.${DEVICE_ARCH} (render-only libmpv, software
# decode, GPU-agnostic) so playback works on CFWs that ship no libmpv (RockNIX)
# and avoids ffmpeg-version mismatches. curl/TLS static in the binary. Needs network.

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

# --- เพิ่มการรองรับ SD2 (เมม 2) ตรงบล็อกนี้ ---
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
elif [ -d "/roms2/ports/PortMaster/" ]; then   # <--- เพิ่มเช็คเมม 2 ตรงนี้
  controlfolder="/roms2/ports/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"       # <--- ค่าเริ่มต้นเมม 1
fi
# ----------------------------------------

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/ytc"
cd "$GAMEDIR"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

export LD_LIBRARY_PATH="$GAMEDIR/libs.${DEVICE_ARCH}:$LD_LIBRARY_PATH"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# Handheld-class defaults: cap the ladder at 480p (software decode on
# small ARM cores; the panel is 480p anyway). Font ships in data/.
export YTC_MAXHEIGHT=480

$GPTOKEYB "ytc.${DEVICE_ARCH}" &
pm_platform_helper "$GAMEDIR/ytc.${DEVICE_ARCH}"

./ytc.${DEVICE_ARCH}

pm_finish